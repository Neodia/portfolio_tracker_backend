use super::client::CGClient;
use super::model::{GetPricesFromNetworkResponse, GetSimplePriceRequest, GetSimplePriceResponse};
use crate::client::cg_model::CGGetPricesFromNetworkResponse;
use crate::client::error::ClientError;
use crate::client::util::join_as_csv;
use crate::model::Network;
use crate::model::contract::Contract;
use reqwest::Client;

pub struct LiveCGClient {
    base_url: String,
    cg_key: String,
    client: Client,
}

impl LiveCGClient {
    pub fn new(base_url: String, cg_key: String, client: Client) -> LiveCGClient {
        Self {
            base_url,
            cg_key,
            client,
        }
    }
}

impl LiveCGClient {
    fn get(&self, url: String) -> reqwest::RequestBuilder {
        self.client
            .get(url)
            .header("x-cg-demo-api-key", &self.cg_key)
    }
}

impl CGClient for LiveCGClient {
    async fn get_simple_price(
        &self,
        ids: &[&str],
        vs_currencies: &[&str],
    ) -> Result<GetSimplePriceResponse, ClientError> {
        let response = self
            .get(format!("{}/simple/price", self.base_url))
            .query(&GetSimplePriceRequest::new(
                ids.to_vec(),
                vs_currencies.to_vec(),
            ))
            .send()
            .await?
            .json::<GetSimplePriceResponse>()
            .await?;

        Ok(response)
    }

    async fn get_prices_from_network(
        &self,
        network: Network,
        contracts: &[Contract],
    ) -> Result<GetPricesFromNetworkResponse, ClientError> {
        let response = self
            .get(format!(
                "{}/onchain/networks/{}/tokens/multi/{}",
                self.base_url,
                network,
                join_as_csv(contracts)
            ))
            .send()
            .await?
            .json::<CGGetPricesFromNetworkResponse>()
            .await
            .map(Into::into)?;

        Ok(response)
    }
}
